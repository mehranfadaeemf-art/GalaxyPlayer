plugins { id("com.android.application") }
android {
    namespace = "dev.galaxy.player"
    compileSdk = 35
    defaultConfig {
        applicationId = "dev.galaxy.player"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "2.0-preview"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    buildTypes { getByName("release") { isMinifyEnabled = false } }
}
dependencies {
    // Last legacy ExoPlayer line: supports API 21 without a modern Compose runtime.
    implementation("com.google.android.exoplayer:exoplayer:2.19.1")
    testImplementation("junit:junit:4.13.2")
}
