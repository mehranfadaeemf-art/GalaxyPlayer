package dev.galaxy.player;

import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public class DspCoreTest {
    @After public void restore(){DspCore.config=new DspCore.Config(new float[16],-6,0,0,.2f,true);}
    private DspCore core(int rate,int channels,float[] db,float pre,float bal,int room,float wet,boolean on){
        DspCore.config=new DspCore.Config(db,pre,bal,room,wet,on);
        DspCore dsp=new DspCore();dsp.configure(rate,channels);dsp.update();return dsp;
    }
    @Test public void disabledIsBitExact(){
        DspCore d=core(48000,2,new float[16],-24,1,3,.5f,false);
        for(float x:new float[]{-1,-.3f,0,.1f,1})assertEquals(x,d.process(x,0),0);
    }
    @Test public void flatHasUnityGain(){
        DspCore d=core(44100,1,new float[16],0,0,0,0,true);
        for(int i=0;i<10000;i++){float x=(float)Math.sin(i*.12)*.5f;assertEquals(x,d.process(x,0),.000001f);}
    }
    @Test public void preampIsMeasuredInDb(){
        DspCore d=core(44100,1,new float[16],-6,0,0,0,true);
        assertEquals(.5*Math.pow(10,-6/20.0),d.process(.5f,0),.000001);
    }
    @Test public void balanceMutesOnlySelectedSide(){
        DspCore d=core(48000,2,new float[16],0,1,0,0,true);
        assertEquals(0,d.process(.5f,0),0);assertEquals(.5f,d.process(.5f,1),.000001f);
        DspCore.config=new DspCore.Config(new float[16],0,-1,0,0,true);d.update();
        assertEquals(.5f,d.process(.5f,0),.000001f);assertEquals(0,d.process(.5f,1),0);
    }
    @Test public void allSixteenBandsHaveSixDbCenterGain(){
        for(int band=0;band<16;band++){
            float[] db=new float[16];db[band]=6;
            DspCore d=core(48000,1,db,0,0,0,0,true);double in=0,out=0;
            for(int i=0;i<96000;i++){
                float x=(float)(.01*Math.sin(2*Math.PI*DspCore.FREQUENCIES[band]*i/48000));
                float y=d.process(x,0);
                if(i>=48000){in+=x*x;out+=y*y;}
            }
            assertEquals("Band "+DspCore.FREQUENCIES[band],6,10*Math.log10(out/in),.08);
        }
    }
    @Test public void lowRateAndMaximumBoostStayFinite(){
        float[] db=new float[16];java.util.Arrays.fill(db,12);
        DspCore d=core(8000,1,db,6,0,3,.5f,true);
        for(int i=0;i<80000;i++){float y=d.process((float)Math.sin(i*.17),0);assertFalse(Float.isNaN(y));assertTrue(y>=-1&&y<=1);}
    }
    @Test public void roomProducesTailAndResetClearsIt(){
        DspCore d=core(48000,1,new float[16],0,0,2,.5f,true);
        d.process(.5f,0);double tail=0;
        for(int i=0;i<48000;i++)tail+=Math.abs(d.process(0,0));
        assertTrue(tail>0);d.reset();
        for(int i=0;i<48000;i++)assertEquals(0,d.process(0,0),0);
    }
    @Test public void configurationCopiesBandArray(){
        float[] original=new float[16];DspCore.Config c=new DspCore.Config(original,0,0,0,0,true);
        original[0]=12;assertEquals(0,c.db[0],0);
    }
}
