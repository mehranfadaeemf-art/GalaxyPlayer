package dev.galaxy.player;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import android.text.*;
import com.google.android.exoplayer2.*;
import com.google.android.exoplayer2.trackselection.TrackSelectionOverride;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.util.MimeTypes;
import java.text.Collator;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(9,13,23), PANEL=Color.rgb(22,31,46), BLUE=Color.rgb(54,185,255), COPPER=Color.rgb(222,105,67);
    private PlaybackService service;
    private boolean bound, bindingRequested, fullscreen=false, dragging=false;
    private LinearLayout root, body;
    private PlayerView playerView;
    private TextView now,clock;
    private Button playButton;
    private SeekBar timeline;
    private int page=0,sort=0,scanId=0;
    private String folder="",query="";
    private List<Library.Entry> library=new ArrayList<>(),visible=new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private TextView count;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private String lastError="";
    private final ServiceConnection connection=new ServiceConnection(){
        public void onServiceConnected(ComponentName n,IBinder binder){service=((PlaybackService.LocalBinder)binder).get();bound=true;build();requestAccess();}
        public void onServiceDisconnected(ComponentName n){bound=false;service=null;}
    };
    private final Runnable ticker=new Runnable(){public void run(){
        if(service!=null && now!=null){
            now.setText(service.title+(service.externalUri!=null?"  • صدای جداگانه":""));
            playButton.setText(service.player.getPlayWhenReady()?"❚❚":"▶");
            long pos=service.player.getCurrentPosition(),dur=service.player.getDuration();
            if(!dragging)timeline.setProgress(dur>0?(int)(pos*1000/dur):0);
            clock.setText(time(pos)+" / "+(dur>0?time(dur):"--:--"));
            getWindow().addFlags(service.player.isPlaying() && service.video?WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON:0);
            if(!service.player.isPlaying() || !service.video)getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if(service.error.isEmpty())lastError="";
            if(!service.error.isEmpty() && !lastError.equals(service.error)){lastError=service.error;new AlertDialog.Builder(MainActivity.this).setTitle("پیام پخش").setMessage(lastError).setPositiveButton("باشه",null).show();}
        }
        handler.postDelayed(this,500);
    }};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);
        TextView loading=text("گلکسی پلیر\nدر حال آماده‌سازی…",22);loading.setGravity(Gravity.CENTER);setContentView(loading);
        bindingRequested=bindService(new Intent(this,PlaybackService.class),connection,BIND_AUTO_CREATE);
    }
    @Override protected void onStart(){super.onStart();handler.post(ticker);}
    @Override protected void onStop(){handler.removeCallbacks(ticker);super.onStop();}
    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);executor.shutdownNow();
        if(playerView!=null)playerView.setPlayer(null);
        if(bindingRequested)unbindService(connection);
        super.onDestroy();
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(dp(10),dp(5),dp(10),dp(5));return t;}
    private Button button(String label,Runnable run){Button b=new Button(this);b.setText(label);b.setTextSize(13);b.setTextColor(BLUE);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(4),0,dp(4),0);b.setOnClickListener(v->run.run());return b;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void addEqual(LinearLayout l,View v){l.addView(v,new LinearLayout.LayoutParams(0,dp(48),1));}
    private void build(){
        if(playerView!=null)playerView.setPlayer(null);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        if(Build.VERSION.SDK_INT>=35)root.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        LinearLayout header=row();header.setPadding(dp(8),0,dp(8),0);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.galaxy_icon);header.addView(logo,new LinearLayout.LayoutParams(dp(44),dp(44)));
        TextView brand=text("گلکسی پلیر  /  GALAXY",19);brand.setTextColor(BLUE);brand.setTypeface(null,Typeface.BOLD);header.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
        header.addView(button("⋮",this::menu),new LinearLayout.LayoutParams(dp(44),dp(48)));root.addView(header);
        playerView=new PlayerView(this);playerView.setPlayer(service.player);playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        root.addView(playerView,new LinearLayout.LayoutParams(-1,dp(190)));playerView.setVisibility(service.video?View.VISIBLE:View.GONE);
        now=text(service.title,16);now.setMaxLines(1);root.addView(now);
        LinearLayout transport=row();
        addEqual(transport,button("قبلی",()->service.player.seekToPreviousMediaItem()));
        playButton=button("▶",()->{if(service.player.getMediaItemCount()==0){toast("ابتدا یک فایل انتخاب کن");return;}service.ensureStarted();if(service.player.getPlayWhenReady())service.player.pause();else service.player.play();});addEqual(transport,playButton);
        addEqual(transport,button("بعدی",()->service.player.seekToNextMediaItem()));
        addEqual(transport,button("صدا / زیرنویس",this::videoMenu));root.addView(transport);
        LinearLayout seekRow=row();timeline=new SeekBar(this);timeline.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);timeline.setMax(1000);seekRow.addView(timeline,new LinearLayout.LayoutParams(0,dp(32),1));
        clock=text("0:00",11);seekRow.addView(clock);root.addView(seekRow);
        timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar s){dragging=true;}
            public void onProgressChanged(SeekBar s,int p,boolean user){}
            public void onStopTrackingTouch(SeekBar s){long dur=service.player.getDuration();if(dur>0)service.player.seekTo(dur*s.getProgress()/1000);dragging=false;}
        });
        LinearLayout tabs=row();addEqual(tabs,button("♫ موسیقی",()->switchPage(0)));addEqual(tabs,button("▶ فیلم",()->switchPage(1)));addEqual(tabs,button("☷ اکولایزر",()->switchPage(2)));root.addView(tabs);
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);switchPage(page);
    }
    private void switchPage(int p){
        page=p;scanId++;body.removeAllViews();
        if(p==2){effects();return;}
        library=new ArrayList<>();folder="";query="";
        EditText search=new EditText(this);search.setSingleLine();search.setTextColor(Color.WHITE);search.setHintTextColor(0xff9ca8bd);search.setTextSize(14);search.setHint(p==0?"جست‌وجوی آهنگ…":"جست‌وجوی فیلم…");body.addView(search,new LinearLayout.LayoutParams(-1,dp(44)));
        LinearLayout actions=row();addEqual(actions,button("پوشه‌ها",this::folders));addEqual(actions,button("مرتب‌سازی",this::sorting));addEqual(actions,button("بازکردن فایل",()->pick(page==1?11:10)));body.addView(actions);
        count=text("در حال خواندن فایل‌ها…",12);count.setTextColor(COPPER);body.addView(count);
        ListView list=new ListView(this);list.setDividerHeight(dp(5));
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,new ArrayList<>()){
            @Override public View getView(int pos,View recycled,android.view.ViewGroup parent){
                TextView t=(TextView)super.getView(pos,recycled,parent);t.setTextColor(Color.WHITE);t.setTextSize(15);t.setPadding(dp(14),dp(14),dp(14),dp(14));
                GradientDrawable bg=new GradientDrawable();bg.setColor(PANEL);bg.setCornerRadius(dp(12));t.setBackground(bg);return t;
            }
        };
        list.setAdapter(adapter);body.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        list.setOnItemClickListener((parent,view,pos,id)->{
            ArrayList<MediaItem> items=new ArrayList<>();for(Library.Entry e:visible)items.add(e.item());
            service.play(items,pos,page==1);playerView.setVisibility(service.video?View.VISIBLE:View.GONE);
        });
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){query=s.toString();filter();}public void afterTextChanged(Editable e){}});
        scan();
    }
    private void scan(){
        if(page==2)return;
        final int id=++scanId;final boolean vid=page==1;
        executor.execute(()->{
            try {List<Library.Entry> entries=Library.scan(this,vid);handler.post(()->{if(!isDestroyed()&&id==scanId){library=entries;filter();}});}
            catch(Exception e){handler.post(()->{if(!isDestroyed()&&id==scanId)count.setText("دسترسی به فایل‌ها لازم است؛ یا از «بازکردن فایل» استفاده کن.");});}
        });
    }
    private void filter(){
        if(page==2||adapter==null)return;
        ArrayList<Library.Entry> result=new ArrayList<>();String q=query.toLowerCase(Locale.ROOT);
        for(Library.Entry e:library)if((folder.isEmpty()||folder.equals(e.folder)) && e.title.toLowerCase(Locale.ROOT).contains(q))result.add(e);
        Collator col=Collator.getInstance(new Locale("fa"));
        Collections.sort(result,(a,b)->{switch(sort){case 1:return col.compare(b.title,a.title);case 2:return Long.compare(b.added,a.added);case 3:return Long.compare(a.added,b.added);case 4:return Long.compare(b.modified,a.modified);default:return col.compare(a.title,b.title);}});
        visible=result;adapter.clear();for(Library.Entry e:result)adapter.add((e.video?"▶  ":"♫  ")+e.title);adapter.notifyDataSetChanged();
        count.setText(result.size()+" فایل  •  "+(folder.isEmpty()?"همه پوشه‌ها":folder));
    }
    private void folders(){
        TreeSet<String> set=new TreeSet<>();for(Library.Entry e:library)set.add(e.folder);
        ArrayList<String> names=new ArrayList<>();names.add("همه پوشه‌ها");names.addAll(set);
        new AlertDialog.Builder(this).setTitle("پوشه‌ها").setItems(names.toArray(new String[0]),(d,i)->{folder=i==0?"":names.get(i);filter();}).show();
    }
    private void sorting(){new AlertDialog.Builder(this).setTitle("مرتب‌سازی").setSingleChoiceItems(new String[]{"نام: الف تا ی","نام: ی تا الف","جدیدترین زمان اضافه‌شدن","قدیمی‌ترین زمان اضافه‌شدن","آخرین تغییر فایل"},sort,(d,i)->{sort=i;filter();d.dismiss();}).show();}
    private void requestAccess(){
        if(Build.VERSION.SDK_INT<23){scan();return;}
        ArrayList<String> permissions=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=33){permissions.add(Manifest.permission.READ_MEDIA_AUDIO);permissions.add(Manifest.permission.READ_MEDIA_VIDEO);permissions.add(Manifest.permission.POST_NOTIFICATIONS);}
        else permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        ArrayList<String> needed=new ArrayList<>();for(String s:permissions)if(checkSelfPermission(s)!=PackageManager.PERMISSION_GRANTED)needed.add(s);
        if(!needed.isEmpty())requestPermissions(needed.toArray(new String[0]),50);else scan();
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] results){super.onRequestPermissionsResult(r,p,results);scan();}
    private void pick(int code){
        if((code==12||code==13)&&(!service.video||service.player.getCurrentMediaItem()==null)){toast("اول یک فیلم باز کن");return;}
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(code==11?"video/*":code==13?"*/*":"audio/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(i,code);}catch(ActivityNotFoundException e){toast("فایل‌گزین روی دستگاه پیدا نشد");}
    }
    private String name(Uri uri){
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}
        return uri.getLastPathSegment()==null?"فایل":uri.getLastPathSegment();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null||service==null)return;
        Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
        if(request==12){service.setExternal(uri);toast("صدای جداگانه انتخاب شد؛ هماهنگی را از منوی صدا تنظیم کن");return;}
        if(request==13){
            String n=name(uri).toLowerCase(Locale.ROOT);String mime;
            if(n.endsWith(".srt"))mime=MimeTypes.APPLICATION_SUBRIP;
            else if(n.endsWith(".vtt"))mime=MimeTypes.TEXT_VTT;
            else if(n.endsWith(".ssa")||n.endsWith(".ass"))mime=MimeTypes.TEXT_SSA;
            else {toast("فایل SRT، VTT، SSA یا ASS انتخاب کن (ترجیحاً UTF-8)");return;}
            MediaItem current=service.player.getCurrentMediaItem();if(current==null)return;
            MediaItem.SubtitleConfiguration sub=new MediaItem.SubtitleConfiguration.Builder(uri).setMimeType(mime).setLabel(name(uri)).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build();
            long pos=service.player.getCurrentPosition();boolean playing=service.player.getPlayWhenReady();
            service.selector.setParameters(service.selector.buildUponParameters().clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT,false));
            service.player.setMediaItem(current.buildUpon().setSubtitleConfigurations(Collections.singletonList(sub)).build(),pos);service.player.prepare();service.player.setPlayWhenReady(playing);return;
        }
        if(request==10||request==11){
            MediaItem item=new MediaItem.Builder().setUri(uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(name(uri)).build()).build();
            service.play(Collections.singletonList(item),0,request==11);playerView.setVisibility(service.video?View.VISIBLE:View.GONE);
        }
    }
    private void videoMenu(){
        new AlertDialog.Builder(this).setTitle("صدا و زیرنویس").setItems(new String[]{"انتخاب صدای داخل فیلم","اتصال فایل صدای جداگانه","برگشت به صدای اصلی","هماهنگی صدای جداگانه","انتخاب زیرنویس داخل فیلم","بازکردن زیرنویس جداگانه","نمایش تمام‌صفحه"},(d,i)->{
            if(i==0){service.clearExternal();tracks(C.TRACK_TYPE_AUDIO);}
            if(i==1)pick(12);if(i==2)service.clearExternal();if(i==3)delayDialog();if(i==4)tracks(C.TRACK_TYPE_TEXT);if(i==5)pick(13);if(i==6){if(service.video)setFullscreen(true);else toast("اول یک فیلم پخش کن");}
        }).show();
    }
    private void tracks(int type){
        ArrayList<String> labels=new ArrayList<>();ArrayList<TrackSelectionOverride> overrides=new ArrayList<>();
        labels.add(type==C.TRACK_TYPE_TEXT?"خاموش":"خودکار");overrides.add(null);
        for(Tracks.Group group:service.player.getCurrentTracks().getGroups())if(group.getType()==type){
            for(int i=0;i<group.length;i++)if(group.isTrackSupported(i)){
                Format f=group.getTrackFormat(i);
                String label=(f.label==null?"ترک "+(labels.size()):f.label)+" / "+(f.language==null?"بدون نام زبان":f.language);
                labels.add(label);overrides.add(new TrackSelectionOverride(group.getMediaTrackGroup(),i));
            }
        }
        new AlertDialog.Builder(this).setTitle(type==C.TRACK_TYPE_TEXT?"زیرنویس":"ترک صوتی").setItems(labels.toArray(new String[0]),(d,i)->{
            com.google.android.exoplayer2.trackselection.DefaultTrackSelector.Parameters.Builder p=service.selector.buildUponParameters().clearOverridesOfType(type).setTrackTypeDisabled(type,type==C.TRACK_TYPE_TEXT && i==0);
            if(i>0)p.addOverride(overrides.get(i));service.selector.setParameters(p);
        }).show();
    }
    private void delayDialog(){
        if(service.externalUri==null){toast("ابتدا فایل صدای جداگانه انتخاب کن");return;}
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);
        panel.addView(text("مثبت: صدا دیرتر پخش شود\nمنفی: صدا جلوتر پخش شود",14));
        slider(panel,"تأخیر صدا (میلی‌ثانیه)",100,(int)(service.audioDelayMs/100)+50,p->{service.audioDelayMs=(p-50)*100L;service.syncExternal(true);return service.audioDelayMs+" ms";});
        new AlertDialog.Builder(this).setTitle("هماهنگی صدا ±۵ ثانیه").setView(panel).setPositiveButton("تمام",null).show();
    }
    private interface SliderAction {String update(int p);}
    private void slider(LinearLayout parent,String name,int max,int progress,SliderAction action){
        TextView label=text(name,14);parent.addView(label);
        SeekBar bar=new SeekBar(this);bar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);bar.setMax(max);bar.setProgress(progress);parent.addView(bar,new LinearLayout.LayoutParams(-1,dp(38)));
        label.setText(name+"   "+action.update(progress));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){EffectsStore.save(MainActivity.this);}public void onProgressChanged(SeekBar s,int p,boolean user){if(user)label.setText(name+"   "+action.update(p));}});
    }
    private void change(float[] db,Float pre,Float balance,Integer room,Float wet,Boolean enabled){
        DspCore.Config c=DspCore.config;
        DspCore.config=new DspCore.Config(db==null?c.db:db,pre==null?c.preamp:pre,balance==null?c.balance:balance,room==null?c.room:room,wet==null?c.wet:wet,enabled==null?c.enabled:enabled);
    }
    private void effects(){
        ScrollView scroll=new ScrollView(this);LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(8),0,dp(8),dp(20));scroll.addView(panel);body.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        TextView heading=text("پردازش صوتی واقعی • ۱۶ باند",19);heading.setTextColor(BLUE);panel.addView(heading);
        panel.addView(text("برای موسیقی و فیلم، شامل صدای جداگانه. افزایش زیاد باندها ممکن است اعوجاج ایجاد کند؛ پیش‌تقویت را پایین بیاور. بالانس روی صدای استریو اثر دارد.",12));
        Switch enabled=new Switch(this);enabled.setText("فعال‌بودن پردازش صدا");enabled.setTextColor(Color.WHITE);enabled.setChecked(DspCore.config.enabled);panel.addView(enabled);
        enabled.setOnCheckedChangeListener((v,on)->{change(null,null,null,null,null,on);EffectsStore.save(this);});
        panel.addView(button("حالت آماده / ذخیره تنظیم دلخواه",this::presets));
        slider(panel,"پیش‌تقویت",30,Math.round(DspCore.config.preamp)+24,p->{change(null,(float)p-24,null,null,null,null);return (p-24)+" dB";});
        slider(panel,"بالانس: چپ ← وسط → راست",200,Math.round(DspCore.config.balance*100)+100,p->{change(null,null,(p-100)/100f,null,null,null);return Integer.toString(p-100);});
        Spinner room=new Spinner(this);ArrayAdapter<String> rooms=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"افکت خاموش","اتاق / Room","هال / Hall","کنسرت / Concert"});room.setAdapter(rooms);room.setSelection(DspCore.config.room);panel.addView(room);
        room.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> parent,View v,int pos,long id){change(null,null,null,pos,null,null);EffectsStore.save(MainActivity.this);}});
        slider(panel,"میزان افکت",50,Math.round(DspCore.config.wet*100),p->{change(null,null,null,null,p/100f,null);return p+"%";});
        for(int i=0;i<16;i++){
            final int band=i;int hz=DspCore.FREQUENCIES[i];
            slider(panel,hz>=1000?String.format(Locale.US,"%.1f kHz",hz/1000f):hz+" Hz",48,Math.round(DspCore.config.db[i]*2)+24,p->{float[] values=DspCore.config.db.clone();values[band]=(p-24)/2f;change(values,null,null,null,null,null);return String.format(Locale.US,"%+.1f dB",values[band]);});
        }
        panel.addView(text("بازه هر باند: ‎−۱۲ تا ‎+۱۲ dB. فرکانس‌های بالاتر از محدوده نرخ نمونه‌برداری فایل غیرفعال می‌شوند. افکت‌ها بازتاب الگوریتمی‌اند، نه شبیه‌سازی اندازه‌گیری‌شده سالن واقعی.",12));
    }
    private void presets(){
        new AlertDialog.Builder(this).setTitle("تنظیم صدا").setItems(new String[]{"تخت / Flat","بیس ملایم","وضوح گفتار","ذخیره حالت دلخواه","بارگذاری حالت دلخواه"},(d,i)->{
            if(i==3){android.content.SharedPreferences.Editor e=getSharedPreferences("preset",0).edit();DspCore.Config c=DspCore.config;for(int b=0;b<16;b++)e.putFloat("b"+b,c.db[b]);e.putFloat("pre",c.preamp).putFloat("bal",c.balance).putInt("room",c.room).putFloat("wet",c.wet).putBoolean("saved",true).apply();toast("ذخیره شد");return;}
            float[] db=new float[16];
            if(i==4){android.content.SharedPreferences p=getSharedPreferences("preset",0);if(!p.getBoolean("saved",false)){toast("هنوز حالتی ذخیره نشده");return;}for(int b=0;b<16;b++)db[b]=p.getFloat("b"+b,0);change(db,p.getFloat("pre",-6),p.getFloat("bal",0),p.getInt("room",0),p.getFloat("wet",.2f),true);}
            else {if(i==1){db[1]=2;db[2]=4;db[3]=3;db[4]=1;}if(i==2){db[3]=-2;db[4]=-2;db[8]=2;db[9]=3;db[10]=3;db[11]=1;}change(db,-6f,0f,0,.2f,true);}
            EffectsStore.save(this);body.removeAllViews();effects();
        }).show();
    }
    private void menu(){new AlertDialog.Builder(this).setTitle("گلکسی پلیر").setItems(new String[]{"اسکن دوباره کتابخانه","پخش تصادفی: تغییر وضعیت","تکرار: خاموش / یک / همه","درباره و محدودیت‌ها"},(d,i)->{
        if(i==0)requestAccess();
        if(i==1){boolean on=!service.player.getShuffleModeEnabled();service.player.setShuffleModeEnabled(on);toast(on?"تصادفی روشن":"تصادفی خاموش");}
        if(i==2){int mode=(service.player.getRepeatMode()+1)%3;service.player.setRepeatMode(mode);toast(mode==0?"تکرار خاموش":mode==1?"تکرار یک فایل":"تکرار همه");}
        if(i==3)new AlertDialog.Builder(this).setTitle("Galaxy Player 2.0 preview").setMessage("برای Android 5.0+\nاکولایزر نرم‌افزاری ۱۶ باند، بالانس و بازتاب محیطی.\nپشتیبانی فرمت به کدک گوشی وابسته است؛ همه فایل‌های MKV یا MP4 الزاماً پخش نمی‌شوند.\nصدای جداگانه با دو پخش‌کننده و اصلاح اختلاف زمانی همگام می‌شود؛ دقت در حد نمونه صوتی تضمین نمی‌شود.\nبرای S4 ویدئوی H.264 با صدای AAC و رزولوشن پایین‌تر انتخاب کن.\nنسخه آزمایشی؛ اجرا روی S4 هنوز تأیید نشده است.\nPowered by ExoPlayer 2.19.1 (Apache 2.0).") .setPositiveButton("باشه",null).show();
    }).show();}
    private void setFullscreen(boolean on){
        fullscreen=on;
        for(int i=0;i<root.getChildCount();i++){View v=root.getChildAt(i);if(v!=playerView)v.setVisibility(on?View.GONE:View.VISIBLE);}
        playerView.setLayoutParams(new LinearLayout.LayoutParams(-1,on?-1:dp(190)));playerView.setVisibility(on||service.video?View.VISIBLE:View.GONE);
        getWindow().getDecorView().setSystemUiVisibility(on?View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY:0);
    }
    @Override public void onBackPressed(){if(fullscreen)setFullscreen(false);else super.onBackPressed();}
    private String time(long ms){long sec=Math.max(0,ms)/1000;return String.format(Locale.US,"%d:%02d",sec/60,sec%60);}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
}
