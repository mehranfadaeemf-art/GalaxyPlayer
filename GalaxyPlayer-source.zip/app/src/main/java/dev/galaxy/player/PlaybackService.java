package dev.galaxy.player;

import android.app.*;
import android.content.*;
import android.media.AudioManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.*;
import android.net.Uri;
import com.google.android.exoplayer2.*;
import com.google.android.exoplayer2.audio.*;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import java.util.*;

public class PlaybackService extends Service {
    public final class LocalBinder extends Binder { public PlaybackService get(){return PlaybackService.this;} }
    public ExoPlayer player, external;
    public DefaultTrackSelector selector;
    public String title="گلکسی پلیر", error="";
    public boolean video=false;
    public Uri externalUri;
    public long audioDelayMs=0;
    private Handler handler;
    private MediaSession session;
    private boolean foreground;
    private final Runnable ticker=new Runnable(){public void run(){syncExternal(false);handler.postDelayed(this,250);}};

    private DefaultRenderersFactory renderers() {
        return new DefaultRenderersFactory(this) {
            @Override protected AudioSink buildAudioSink(Context context,boolean floatOutput,boolean playbackParams,boolean offload) {
                return new DefaultAudioSink.Builder(context)
                    .setAudioCapabilities(AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES)
                    .setEnableFloatOutput(false)
                    .setAudioProcessors(new AudioProcessor[]{new GalaxyAudioProcessor()}).build();
            }
        };
    }
    @Override public void onCreate(){
        super.onCreate();
        handler=new Handler(Looper.getMainLooper());
        EffectsStore.load(this);
        selector=new DefaultTrackSelector(this);
        player=new ExoPlayer.Builder(this,renderers()).setTrackSelector(selector).build();
        external=new ExoPlayer.Builder(this,renderers()).build();
        com.google.android.exoplayer2.audio.AudioAttributes attributes = new com.google.android.exoplayer2.audio.AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build();
        player.setAudioAttributes(attributes,true);
        external.setAudioAttributes(attributes,false);
        player.setHandleAudioBecomingNoisy(true);
        player.setWakeMode(C.WAKE_MODE_LOCAL);
        external.setWakeMode(C.WAKE_MODE_LOCAL);
        session=new MediaSession(this,"GalaxyPlayer");
        session.setCallback(new MediaSession.Callback(){
            @Override public void onPlay(){player.play();}
            @Override public void onPause(){player.pause();}
            @Override public void onSkipToNext(){player.seekToNextMediaItem();}
            @Override public void onSkipToPrevious(){player.seekToPreviousMediaItem();}
            @Override public void onSeekTo(long pos){player.seekTo(pos);}
        });
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS|MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setActive(true);
        player.addListener(new Player.Listener(){
            @Override public void onIsPlayingChanged(boolean playing){syncExternal(true);updateNotification();}
            @Override public void onPlaybackStateChanged(int state){syncExternal(true);updateNotification();}
            @Override public void onMediaItemTransition(MediaItem item,int reason){
                if(externalUri!=null && (reason==Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || reason==Player.MEDIA_ITEM_TRANSITION_REASON_SEEK))clearExternal();
                if(item!=null && item.mediaMetadata.title!=null) title=item.mediaMetadata.title.toString();
                updateNotification();
            }
            @Override public void onPositionDiscontinuity(Player.PositionInfo oldP,Player.PositionInfo newP,int reason){syncExternal(true);}
            @Override public void onPlayerError(PlaybackException e){error="خطای پخش: "+e.getErrorCodeName()+"\n"+e.getMessage();updateNotification();}
        });
        external.addListener(new Player.Listener(){
            @Override public void onPlayerError(PlaybackException e){error="صدای جداگانه قابل پخش نیست: "+e.getErrorCodeName();clearExternal();}
        });
        handler.post(ticker);
    }
    public void ensureStarted(){
        Intent i=new Intent(this,PlaybackService.class);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }
    @Override public int onStartCommand(Intent intent,int flags,int id){
        foreground=true;
        startForeground(7,notification());
        if(intent!=null){
            String a=intent.getAction();
            if("toggle".equals(a)){if(player.getPlayWhenReady())player.pause();else player.play();}
            if("next".equals(a))player.seekToNextMediaItem();
            if("stop".equals(a)){player.pause();clearExternal();foreground=false;stopForeground(true);stopSelf();}
        }
        return START_NOT_STICKY;
    }
    public void play(List<MediaItem> items,int index,boolean video){
        ensureStarted(); clearExternal(); this.video=video; error="";
        // Track choices from a previous film must not leak into a new one.
        selector.setParameters(selector.buildUponParameters().clearOverrides().setTrackTypeDisabled(C.TRACK_TYPE_TEXT,false));
        player.setRepeatMode(Player.REPEAT_MODE_OFF);
        player.setShuffleModeEnabled(false);
        player.setMediaItems(items,index,0);player.prepare();player.play();
    }
    public void setExternal(Uri uri){
        if(!video)return;
        externalUri=uri;audioDelayMs=0;error="";
        external.setMediaItem(MediaItem.fromUri(uri));external.prepare();player.setVolume(0);syncExternal(true);
    }
    public void clearExternal(){externalUri=null;external.stop();external.clearMediaItems();player.setVolume(1);audioDelayMs=0;}
    public void syncExternal(boolean force){
        if(externalUri==null)return;
        long target=player.getCurrentPosition()-audioDelayMs;
        long duration=external.getDuration();
        boolean inRange=target>=0 && (duration==C.TIME_UNSET || target<duration);
        long position=Math.max(0,target);
        if(duration!=C.TIME_UNSET)position=Math.min(position,Math.max(0,duration));
        if(force || (inRange && Math.abs(external.getCurrentPosition()-position)>180))external.seekTo(position);
        external.setPlayWhenReady(player.isPlaying() && inRange);
    }
    private PendingIntent action(String a,int id){return PendingIntent.getService(this,id,new Intent(this,PlaybackService.class).setAction(a),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private Notification notification(){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel("playback","پخش رسانه",NotificationManager.IMPORTANCE_LOW));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"playback"):new Notification.Builder(this);
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText("گلکسی پلیر")
            .setContentIntent(open).setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(player.getPlayWhenReady())
            .addAction(android.R.drawable.ic_media_pause,player.getPlayWhenReady()?"مکث":"پخش",action("toggle",1))
            .addAction(android.R.drawable.ic_media_next,"بعدی",action("next",2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel,"توقف",action("stop",3))
            .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));
        return b.build();
    }
    private void updateNotification(){
        long actions=PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_SEEK_TO|PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions)
            .setState(player.isPlaying()?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,player.getCurrentPosition(),player.isPlaying()?1:0).build());
        session.setMetadata(new android.media.MediaMetadata.Builder().putString(android.media.MediaMetadata.METADATA_KEY_TITLE,title).build());
        if(foreground)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7,notification());
    }
    @Override public IBinder onBind(Intent i){return new LocalBinder();}
    @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);player.release();external.release();session.release();super.onDestroy();}
}
