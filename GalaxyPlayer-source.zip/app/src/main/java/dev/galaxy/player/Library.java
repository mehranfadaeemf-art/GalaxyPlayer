package dev.galaxy.player;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.MediaMetadata;
import java.util.*;

public final class Library {
    public static final class Entry {
        public Uri uri; public String title,folder; public long added,modified;public boolean video;
        public MediaItem item(){return new MediaItem.Builder().setUri(uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(title).build()).build();}
    }
    public static List<Entry> scan(Context c,boolean video){
        ArrayList<Entry> result=new ArrayList<>();
        Uri base=video?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String folderColumn=Build.VERSION.SDK_INT>=29?"relative_path":"_data";
        String[] cols={"_id","_display_name","date_added","date_modified",folderColumn};
        try(Cursor cur=c.getContentResolver().query(base,cols,null,null,null)){
            if(cur!=null)while(cur.moveToNext()){
                Entry e=new Entry();e.uri=ContentUris.withAppendedId(base,cur.getLong(0));
                e.title=cur.getString(1);if(e.title==null)e.title="بدون نام";
                e.added=cur.getLong(2);e.modified=cur.getLong(3);e.video=video;
                String path=cur.getString(4);
                if(path==null)e.folder="نامشخص";
                else if(Build.VERSION.SDK_INT>=29)e.folder=path;
                else {int slash=path.lastIndexOf('/');e.folder=slash>=0?path.substring(0,slash):"نامشخص";}
                result.add(e);
            }
        }
        return result;
    }
}
