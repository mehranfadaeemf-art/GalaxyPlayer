package dev.galaxy.player;

/** Allocation-free per-frame DSP. Audio must be decoded to PCM (no passthrough/offload). */
public final class DspCore {
    public static final int[] FREQUENCIES = {25,40,63,100,160,250,400,630,1000,1600,2500,4000,6300,10000,14000,18000};
    public static final class Config {
        public final float[] db;
        public final float preamp, balance, wet;
        public final int room;
        public final boolean enabled;
        public Config(float[] db, float preamp, float balance, int room, float wet, boolean enabled) {
            this.db = db.clone(); this.preamp = preamp; this.balance = balance;
            this.room = room; this.wet = wet; this.enabled = enabled;
        }
    }
    public static volatile Config config = new Config(new float[16], -6, 0, 0, .2f, true);
    private Config applied;
    private final double[][] coef = new double[16][5];
    private double[][] z1, z2;
    private float[][][] delay;
    private int[][] index;
    private float[][] damp;
    private int sampleRate, channels;
    private double gain, left, right, feedback;
    public void configure(int rate, int channels) {
        this.sampleRate=rate; this.channels=channels;
        z1=new double[channels][16]; z2=new double[channels][16];
        delay=new float[channels][4][]; index=new int[channels][4]; damp=new float[channels][4];
        double[] seconds={.0297,.0371,.0411,.0437};
        for(int c=0;c<channels;c++) for(int k=0;k<4;k++)
            delay[c][k]=new float[Math.max(1,(int)(rate*(seconds[k]+c*.0013)))];
        applied=null;
    }
    public void update() {
        Config v=config;
        if(v==applied) return;
        for(int b=0;b<16;b++) {
            double[] a=coef[b];
            if(FREQUENCIES[b]>=sampleRate*.48) { a[0]=1; a[1]=a[2]=a[3]=a[4]=0; continue; }
            double A=Math.pow(10,v.db[b]/40.0), w=2*Math.PI*FREQUENCIES[b]/sampleRate;
            double alpha=Math.sin(w)/(2*2.1), cos=Math.cos(w), a0=1+alpha/A;
            a[0]=(1+alpha*A)/a0; a[1]=-2*cos/a0; a[2]=(1-alpha*A)/a0;
            a[3]=-2*cos/a0; a[4]=(1-alpha/A)/a0;
        }
        gain=Math.pow(10,v.preamp/20.0);
        left=v.balance>0?1-v.balance:1; right=v.balance<0?1+v.balance:1;
        feedback=v.room==1?.58:v.room==2?.78:.87;
        applied=v;
    }
    public float process(float input,int channel) {
        if(applied==null) update();
        if(!applied.enabled) return input;
        double x=input*gain;
        for(int b=0;b<16;b++) {
            double[] a=coef[b];
            double y=a[0]*x+z1[channel][b];
            z1[channel][b]=a[1]*x-a[3]*y+z2[channel][b];
            z2[channel][b]=a[2]*x-a[4]*y;
            x=y;
        }
        if(applied.room!=0) {
            double tail=0;
            for(int k=0;k<4;k++) {
                int p=index[channel][k]; float[] line=delay[channel][k];
                float d=line[p];
                damp[channel][k]=.65f*d+.35f*damp[channel][k];
                line[p]=(float)(x*.22+damp[channel][k]*feedback);
                tail+=d;
                index[channel][k]=(p+1)%line.length;
            }
            x=x*(1-applied.wet)+tail*applied.wet;
        }
        if(channels>=2) x*=channel==0?left:channel==1?right:1;
        if(Double.isNaN(x) || Double.isInfinite(x)) { reset(); return 0; }
        // Safety clipping only; not a look-ahead loudness/mastering limiter.
        return (float)Math.max(-1,Math.min(1,x));
    }
    public void reset() {
        if(z1==null)return;
        for(int c=0;c<channels;c++) {
            java.util.Arrays.fill(z1[c],0); java.util.Arrays.fill(z2[c],0);
            java.util.Arrays.fill(damp[c],0); java.util.Arrays.fill(index[c],0);
            for(float[] line:delay[c])java.util.Arrays.fill(line,0);
        }
    }
}
