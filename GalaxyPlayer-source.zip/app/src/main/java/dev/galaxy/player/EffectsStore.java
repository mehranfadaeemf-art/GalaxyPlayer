package dev.galaxy.player;
import android.content.Context;
import android.content.SharedPreferences;

public final class EffectsStore {
    static void load(Context context){
        SharedPreferences p=context.getSharedPreferences("effects",0);
        float[] db=new float[16];for(int i=0;i<16;i++)db[i]=p.getFloat("band"+i,0);
        DspCore.config=new DspCore.Config(db,p.getFloat("preamp",-6),p.getFloat("balance",0),p.getInt("room",0),p.getFloat("wet",.2f),p.getBoolean("enabled",true));
    }
    static void save(Context context){
        DspCore.Config c=DspCore.config;
        SharedPreferences.Editor e=context.getSharedPreferences("effects",0).edit();
        for(int i=0;i<16;i++)e.putFloat("band"+i,c.db[i]);
        e.putFloat("preamp",c.preamp).putFloat("balance",c.balance).putInt("room",c.room).putFloat("wet",c.wet).putBoolean("enabled",c.enabled).apply();
    }
}
