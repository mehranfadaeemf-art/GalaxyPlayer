package dev.galaxy.player;

import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.audio.BaseAudioProcessor;
import com.google.android.exoplayer2.audio.AudioProcessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class GalaxyAudioProcessor extends BaseAudioProcessor {
    private final DspCore dsp = new DspCore();
    private int channels;
    @Override protected AudioFormat onConfigure(AudioFormat input) throws AudioProcessor.UnhandledAudioFormatException {
        if(input.encoding!=C.ENCODING_PCM_16BIT) throw new AudioProcessor.UnhandledAudioFormatException(input);
        channels=input.channelCount;
        dsp.configure(input.sampleRate,channels);
        return input;
    }
    @Override public void queueInput(ByteBuffer input) {
        input.order(ByteOrder.LITTLE_ENDIAN);
        ByteBuffer out=replaceOutputBuffer(input.remaining()).order(ByteOrder.LITTLE_ENDIAN);
        dsp.update();
        while(input.remaining()>=channels*2) {
            for(int c=0;c<channels;c++) {
                float value=dsp.process(input.getShort()/32768f,c);
                int pcm=Math.max(-32768,Math.min(32767,Math.round(value*32768)));
                out.putShort((short)pcm);
            }
        }
        out.flip();
    }
    @Override protected void onFlush(){dsp.reset();}
    @Override protected void onReset(){dsp.reset();}
}
