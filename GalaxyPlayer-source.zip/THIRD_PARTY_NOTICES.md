# Third-party notices

This source archive does not bundle third-party libraries. Gradle resolves them when building.
The MIT license for this project's original code does not replace dependency licenses.

- ExoPlayer 2.19.1 (Google): Apache License 2.0. https://github.com/google/ExoPlayer/tree/r2.19.1
- AndroidX libraries (Android Open Source Project): Apache License 2.0. https://developer.android.com/jetpack/androidx
- Guava (Google): Apache License 2.0. https://github.com/google/guava
- JUnit 4.13.2 (tests only): Eclipse Public License 1.0. https://github.com/junit-team/junit4
- Hamcrest (transitive test dependency): BSD license. https://github.com/hamcrest/JavaHamcrest

This is an overview of principal dependencies, not an exhaustive audit of transitive dependencies.
Before redistributing a compiled release, review the resolved dependency tree and preserve all required notices and licenses.
Galaxy Player is an independent project, not an official Samsung or Google application.
